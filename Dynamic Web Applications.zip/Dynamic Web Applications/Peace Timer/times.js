let btn1 = document.getElementById("twentySecondsBtn");
let btn2 = document.getElementById("thirtySecondsBtn");
let btn3 = document.getElementById("fortySecondsBtn");
let btn4 = document.getElementById("oneMinuteBtn")
let p = document.getElementById("timerText");
btn1.onclick = function() {
    let counter = 20;
    p.textContent = counter + " seconds left";
    let intervalEl = setInterval(function() {
        counter = counter - 1;
        if (counter === 0) {
            clearInterval(intervalEl);
            p.textContent = "Your moment is complete";
        } else {
            p.textContent = counter + " seconds left";
        }
    }, 1000)
};
btn2.onclick = function() {
    let counter = 30;
    p.textContent = counter + " seconds left";
    let intervalEl = setInterval(function() {
        counter = counter - 1;
        if (counter === 0) {
            clearInterval(intervalEl);
            p.textContent = "Your moment is complete";
        } else {
            p.textContent = counter + " seconds left";
        }
    }, 1000)
};
btn3.onclick = function() {
    let counter = 40;
    p.textContent = counter + " seconds left";
    let intervalEl = setInterval(function() {
        counter = counter - 1;
        if (counter === 0) {
            clearInterval(intervalEl);
            p.textContent = "Your moment is complete";
        } else {
            p.textContent = counter + " seconds left";
        }
    }, 1000)
};
btn4.onclick = function() {
    let counter = 60;
    p.textContent = counter + " seconds left";
    let intervalEl = setInterval(function() {
        counter = counter - 1;
        if (counter === 0) {
            clearInterval(intervalEl);
            p.textContent = "Your moment is complete";
        } else {
            p.textContent = counter + " seconds left";
        }
    }, 1000)
};