let text1 = document.getElementById("fromUserInput");
let text2 = document.getElementById("toUserInput");
let btn = document.getElementById("startBtn");

btn.onclick = function() {
    let v1 = text1.value;
    let v2 = text2.value;

    if (v1 === "") {
        alert("Enter the from value");
    } else if (v2 === "") {
        alert("Enter the to value");
    } else {
        let p = document.getElementById("counterText");
        let counter = parseInt(v1);
        let end = parseInt(v2);

        if (counter >= end) {
            p.textContent = counter;
        } else {

            p.textContent = counter;

            let intervalEl = setInterval(function() {
                counter = counter + 1;
                p.textContent = counter;

                if (counter === end) {
                    clearInterval(intervalEl);
                }
            }, 1000);
        }
    }
};