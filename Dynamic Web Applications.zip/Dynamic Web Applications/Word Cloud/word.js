let wordCloud = ["Hello", "hii", "how", "what", "you", "yourself", "name", "victory", "food", "lovely", "beautiful", "written", "where", "who", "awesome"];
let fontSize = [21, 66, 32, 21, 50, 15, 25, 47, 20, 35, 56, 18, 44, 22, 37, 32, 19, 27, 32, 22];
let container = document.getElementById("wordsContainer");
let input = document.getElementById("userInput");
let error = document.getElementById("errorMsg");
let btn = document.getElementById("addBtn");
let l = fontSize.length;
let l2 = wordCloud.length;
let count = 0;
btn.onclick = function() {
    let size = fontSize[Math.ceil(Math.random() * l)];
    let text = input.value;
    if (text === "") {
        error.textContent = "Please enter a word"; // Set error message
        return;
    }
    error.textContent = "";
    let s = document.createElement("span");
    s.textContent = text + " ";
    s.style.fontSize = size + "px";
    s.classList.add("word-style");
    container.appendChild(s);
    input.value = "";
}