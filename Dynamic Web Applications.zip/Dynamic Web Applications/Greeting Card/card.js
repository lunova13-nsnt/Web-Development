let greeting = '{"greetText":"Wishing that the new year will bring joy, love, peace, and happiness to you.","from":"Rahul","to":"Varakumar"}';

let parseItems = JSON.parse(greeting);
let greet1 = parseItems.from;
let para1 = document.getElementById("greetText1");
para1.textContent = "From: " + greet1;
let greet2 = parseItems.to;
let para2 = document.getElementById("greetText2");
para2.textContent = "From: " + greet2;
let greet3 = parseItems.greetText;
let para3 = document.getElementById("greetText3");
para3.textContent = greet3;