let options = {
    method: "GET",
}
let getBtn = document.getElementById("sendGetRequestBtn");
getBtn.onclick = function() {
    let request = document.getElementById("requestStatus");
    let response = document.getElementById("httpResponse");
    fetch("https://gorest.co.in/public-api/users", options)
        .then(function(response) {
            let v1 = response.status;
            request.textContent = v1;
            return response.text()
        })
        .then(function(data) {
            response.textContent = data
        });
}