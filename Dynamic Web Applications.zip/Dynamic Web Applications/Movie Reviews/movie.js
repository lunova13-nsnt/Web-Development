let container = document.getElementById("movieReviewsContainer");
let head = document.createElement("h1");
head.textContent = "Movie Reviews";
head.classList.add("head");
container.appendChild(head);

let para1 = document.createElement("p");
para1.textContent = "MOVIE TITLE";
para1.classList.add("p1");
container.appendChild(para1);

let titleInput = document.createElement("input");
titleInput.type = "text";
titleInput.id = "titleInput";
container.appendChild(titleInput);

let para2 = document.createElement("p");
para2.textContent = "YOUR REVIEW";
para2.classList.add("p1");
container.appendChild(para2);

let reviewTextarea = document.createElement("textarea");
reviewTextarea.setAttribute("rows", 5);
reviewTextarea.setAttribute("cols", 25);
reviewTextarea.id = "reviewTextarea";
container.appendChild(reviewTextarea);

let btnContainer = document.createElement("div");
btnContainer.classList.add("text-right");
container.appendChild(btnContainer);

let addBtn = document.createElement("button");
addBtn.textContent = "Add";
addBtn.id = "addBtn";
addBtn.classList.add("btn", "btn-primary", "text-white");
btnContainer.appendChild(addBtn);

let reviewsContainer = document.createElement("div");
reviewsContainer.id = "reviewsContainer";
container.appendChild(reviewsContainer);

addBtn.onclick = function() {

    let h = titleInput.value;
    let head1 = document.createElement("h1");
    head1.textContent = "Movie Title: " + h;
    head1.classList.add("h");
    reviewsContainer.appendChild(head1);
    titleInput.value = " ";

    let r = reviewTextarea.value;
    let para = document.createElement("p");
    para.textContent = "Review: " + r;
    para.classList.add("p");
    reviewsContainer.appendChild(para);
    reviewTextarea.value = " ";
}