let num1 = document.getElementById("firstNumber");
let num2 = document.getElementById("secondNumber");
let text = document.getElementById("userInput");
let result = document.getElementById("gameResult");
num1.textContent = 30;
num2.textContent = 77;

function checkButton() {
    let a = num1.textContent;
    let b = num2.textContent;
    let c = parseInt(a) + parseInt(b);
    let i = parseInt(text.value);
    result.classList.remove("para1", "para2");
    if (c === i) {
        result.textContent = "Congratulation! You got it right.";
        result.classList.add("para1");
    } else {
        result.textContent = "Please Try Again!";
        result.classList.add("para2");
    }
}

function restartButton() {
    let n = Math.ceil(Math.random() * 100);
    let m = Math.ceil(Math.random() * 100);
    num1.textContent = n;
    num2.textContent = m;
    text.value = "";
    result.textContent = "";
    result.classList.remove("para1", "para2");
}