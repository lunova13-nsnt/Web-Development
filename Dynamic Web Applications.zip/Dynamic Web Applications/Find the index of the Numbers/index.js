let numbers = [17, 31, 77, 20, 63];
let input = document.getElementById("userInput");
let index = document.getElementById("indexOfNumber");

function findIndexOfNumber() {
    if (input.value !== "") {
        let i = parseInt(input.value);
        let l = numbers.findIndex(function(x) {
            return x === i;
        });
        index.textContent = l;
    }
}