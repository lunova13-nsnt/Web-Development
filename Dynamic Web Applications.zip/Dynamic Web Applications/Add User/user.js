let form = document.getElementById("addUserForm");
let userNameEl = document.getElementById("name");
let emailEl = document.getElementById("email");
let nameErr = document.getElementById("nameErrMsg");
let emailErr = document.getElementById("emailErrMsg");
let workingStatusEl = document.getElementById("status");
let maleEl = document.getElementById("genderMale");
let femaleEl = document.getElementById("genderFemale");

let formData = {
    name: "",
    email: "",
    status: "Active",
    gender: "Male"
};

userNameEl.addEventListener("change", function(event) {
    if (event.target.value === "") {
        nameErr.textContent = "Required*";
    } else {
        nameErr.textContent = "";
    }

    formData.name = event.target.value;
});

emailEl.addEventListener("change", function(event) {
    if (event.target.value === "") {
        emailErr.textContent = "Required*";
    } else {
        emailErr.textContent = "";
    }

    formData.email = event.target.value;
});

workingStatusEl.addEventListener("change", function(event) {
    formData.status = event.target.value;
});

maleEl.addEventListener("change", function(event) {
    formData.gender = event.target.value;
});

femaleEl.addEventListener("change", function(event) {
    formData.gender = event.target.value;
});

function validateFormData(formData) {
    let {
        name,
        email
    } = formData;
    if (name === "") {
        nameErr.textContent = "Required*";
    }
    if (email === "") {
        emailErr.textContent = "Required*";
    }
}

function submitFormData(formData) {
    let options = {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: "Bearer 00f3f8fde06120db02b587cc372c3d85510896e899b45774068bb750462acd9f",
        },
        body: JSON.stringify(formData)
    };

    let url = "https://gorest.co.in/public-api/users";

    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {
            console.log(jsonData);
            if (jsonData.code === 422) {
                if (jsonData.data[0].message === "has already been taken") {
                    emailErr.textContent = "Email Already Exists";
                }
            }
        });
}

form.addEventListener("submit", function(event) {
    event.preventDefault();
    validateFormData(formData);
    submitFormData(formData);
});