let container = document.getElementById("checkboxWithLabelContainer");

let input = document.createElement("input");
input.type = "checkbox";
input.id = "checkbox";
container.appendChild(input);

let label = document.createElement("label");
label.htmlFor = "checkbox";
label.id = "checkboxLabel";
label.textContent = "Click Me!";
container.appendChild(label);