let jokeText = document.getElementById("jokeText");
let jokeBtn = document.getElementById("jokeBtn");
jokeBtn.onclick = function() {
    let spinner = document.getElementById("spinner");
    jokeText.textContent = "";
    spinner.classList.remove("d-none");
    let options = {
        method: "GET"
    }
    fetch("https://apis.ccbp.in/jokes/random", options)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            jokeText.textContent = data.value;
            spinner.classList.add("d-none");
        })
}