let groceryList = ["Apples", "Boost Drink", "Butterscotch Ice Cream", "Tomato Ketchup", "Dairy Milk Chocolates", "Pasta"];
let container = document.getElementById("groceryListContainer");

let head = document.createElement("h1");
head.textContent = "Grocery List";
head.classList.add("head");
container.appendChild(head);

let ulContainer = document.createElement("div");
ulContainer.classList.add("d-flex", "flex-row", "justify-content-center", "ul");
container.appendChild(ulContainer);

let uList = document.createElement("ul");
uList.classList.add("ulContainer");
ulContainer.appendChild(uList);

for (let i of groceryList) {
    let list = document.createElement("li");
    list.textContent = i;
    list.classList.add("list");
    uList.appendChild(list);
}