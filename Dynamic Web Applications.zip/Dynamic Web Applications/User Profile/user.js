let profileDetails = {
    imgSrc: "https://d2clawv67efefq.cloudfront.net/ccbp-dynamic-webapps/user-profile-img.png",
    name: "RAHUL ATTULURI",
    age: 25
};
let profile = document.getElementById("profileContainer");
let imgContainer = document.getElementById("imgContainer");
profile.appendChild(imgContainer);

let imageEl = document.createElement("img");
imageEl.setAttribute("src", profileDetails.imgSrc);
imgContainer.appendChild(imageEl);
imageEl.classList.add("img")

let nameEl = document.createElement("h1");
nameEl.textContent = profileDetails.name;
imgContainer.appendChild(nameEl);
nameEl.classList.add("text")

let ageEl = document.createElement("p");
ageEl.textContent = "Age : " + profileDetails.age;
imgContainer.appendChild(ageEl);
ageEl.classList.add("text1")