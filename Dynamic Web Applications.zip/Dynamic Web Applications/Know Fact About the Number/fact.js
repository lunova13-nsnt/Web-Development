let searchInputEl = document.getElementById("userInput");

let searchResultsEl = document.getElementById("fact");

let spinnerEl = document.getElementById("spinner");

function searchWikipedia(event) {
    if (event.key === "Enter") {
        let searchInput = searchInputEl.value;
        searchResultsEl.textContent = "";
        spinnerEl.classList.remove("d-none");

        let url = "https://apis.ccbp.in/numbers-fact?number=" + searchInput;
        let options = {
            method: "GET"
        };

        fetch(url, options)
            .then(function(response) {
                return response.json();
            })
            .then(function(jsonData) {
                spinnerEl.classList.add("d-none");
                searchResultsEl.textContent = jsonData.fact;
            });
    }
}

searchInputEl.addEventListener("keydown", searchWikipedia);