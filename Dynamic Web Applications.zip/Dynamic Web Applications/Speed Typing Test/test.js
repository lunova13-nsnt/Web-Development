let display = document.getElementById("quoteDisplay");
let input = document.getElementById("quoteInput");
let timer = document.getElementById("timer");
let result = document.getElementById("result");
let submitBtn = document.getElementById("submitBtn");
let resetBtn = document.getElementById("resetBtn");
let spinner = document.getElementById("spinner");
let st;
let formData = {
    content: "",
    time: ""
};

function startTimer() {
    let counter = 0;
    timer.textContent = counter + " seconds";
    formData.time = counter;
    st = setInterval(function() {
        counter++;
        timer.textContent = counter + " seconds";
        formData.time = counter;
    }, 1000);
}

function stopTimer() {
    clearInterval(st);
}

function quoteDisplay() {
    spinner.classList.remove("d-none");
    stopTimer();
    let options = {
        method: "GET",
        header: {
            "content-type": "application/json",
            Accept: "application/json",
            Authorization: "?"
        }
    }
    fetch("https://apis.ccbp.in/random-quote", options)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            spinner.classList.add("d-none");
            display.textContent = data.content;
            formData.content = data.content;
            startTimer();
        });

}
submitBtn.onclick = function() {
    let i = input.value;
    let c = formData.content;
    let s = formData.time;
    if (i === c) {
        stopTimer(st);
        result.textContent = "You typed the sentence in " + s + " seconds";
    } else {
        if (i !== c) {
            result.textContent = "You typed the incorrect sentence";
        }
    }
}
resetBtn.onclick = function() {
    quoteDisplay();
}
quoteDisplay();