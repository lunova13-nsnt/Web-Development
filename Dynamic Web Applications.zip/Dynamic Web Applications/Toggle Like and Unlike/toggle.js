let img = document.getElementById("puppyImage");
let icon = document.getElementById("likeIcon");
let button = document.getElementById("likeButton");
let isLiked = false;

function onClickLikeButton() {
    if (!isLiked) {
        img.src = "https://d2clawv67efefq.cloudfront.net/ccbp-dynamic-webapps/white-puppy-liked-img.png";
        icon.style.color = "#0967d2";
        button.style.backgroundColor = "#0967d2";
        button.style.color = "#ffffff";
        isLiked = true;
    } else {
        img.src = "https://d2clawv67efefq.cloudfront.net/ccbp-dynamic-webapps/white-puppy-img.png";
        icon.style.color = "#9aa5b1";
        button.style.backgroundColor = "#cbd2d9";
        button.style.color = "#9aa5b1";
        isLiked = false;
    }
}