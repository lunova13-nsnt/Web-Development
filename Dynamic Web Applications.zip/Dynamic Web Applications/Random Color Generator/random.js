let bgColorsArray = ["#e75d7c", "#b16cef", "#53cca4", "#efc84d", "#628ef0", "#184b73", "#883e7f", "#ed048b"];
let bg = document.getElementById("bgContainer");

function button() {
    let b = bgColorsArray.length;
    let a = Math.ceil(Math.random() * b);
    bg.style.backgroundColor = bgColorsArray[a];
}