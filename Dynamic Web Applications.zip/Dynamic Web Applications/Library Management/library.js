let input = document.getElementById("searchInput");
let result = document.getElementById("searchResults");
let spinner = document.getElementById("spinner");
let formData = {
    search: ""
};

function displayResult(searchResults) {
    result.innerHTML = "";

    if (searchResults.length === 0) {
        result.textContent = "No results found";
        return;
    }

    for (let book of searchResults) {
        let bookDiv = document.createElement("div");
        bookDiv.classList.add("book-item");

        let img = document.createElement("img");
        img.src = book.imageLink;
        img.alt = book.title;
        bookDiv.appendChild(img);

        let authorP = document.createElement("p");
        authorP.textContent = book.author;
        authorP.classList.add("author");
        bookDiv.appendChild(authorP);

        result.appendChild(bookDiv);
    };
}

function searchResult(formData) {
    let {
        search
    } = formData;

    spinner.classList.remove("d-none");

    let options = {
        method: "GET",
        headers: {
            "Content-type": "application/json",
            Accept: "application/json",
        }
    }
    let url = "https://apis.ccbp.in/book-store?title=" + search;

    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            spinner.classList.add("d-none");
            let {
                search_results
            } = data;
            displayResult(search_results);
        })
        .catch(function(error) {
            spinner.classList.add("d-none");
            result.textContent = "Something went wrong. Please try again.";
            console.error("Fetch error:", error);
        });
}

function enter(event) {
    if (event.key === "Enter") {
        formData.search = input.value.trim();
        if (formData.search !== "") {
            searchResult(formData);
        }
    }
}

input.addEventListener("keydown", enter);