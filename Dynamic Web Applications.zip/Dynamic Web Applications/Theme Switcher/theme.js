let bg = document.getElementById("bgContainer");
let h1 = document.getElementById("heading");
let input = document.getElementById("themeUserInput");

input.addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
        let value = input.value;

        if (value === "Light") {
            bg.style.backgroundImage = "url('https://d2clawv67efefq.cloudfront.net/ccbp-dynamic-webapps/change-theme-light-bg.png')";
            h1.style.color = "#014d40";
        } else if (value === "Dark") {
            bg.style.backgroundImage = "url('https://d2clawv67efefq.cloudfront.net/ccbp-dynamic-webapps/change-theme-dark-bg.png')";
            h1.style.color = "#ffffff";
        } else {
            alert("Enter a valid theme");
        }
    }
});