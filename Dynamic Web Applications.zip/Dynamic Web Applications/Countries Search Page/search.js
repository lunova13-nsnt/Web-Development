let searchInputEl = document.getElementById("searchInput");
let resultCountriesEl = document.getElementById("resultCountries");
let spinnerEl = document.getElementById("spinner");

let countriesList = [];

// Create and append each country card
function createAndAppendCountry(country) {
    let {
        name,
        population,
        flag
    } = country;

    let countryCard = document.createElement("div");
    countryCard.classList.add("country-card", "d-flex", "flex-row", "align-items-center", "border", "p-3", "mb-3");

    let flagImg = document.createElement("img");
    flagImg.src = flag;
    flagImg.alt = name + " flag";
    flagImg.classList.add("me-3");
    flagImg.style.width = "60px";
    flagImg.style.height = "40px";
    countryCard.appendChild(flagImg);

    let countryInfo = document.createElement("div");

    let nameEl = document.createElement("h3");
    nameEl.textContent = name;
    countryInfo.appendChild(nameEl);

    let populationEl = document.createElement("p");
    populationEl.textContent = "Population: " + population;
    countryInfo.appendChild(populationEl);

    countryCard.appendChild(countryInfo);
    resultCountriesEl.appendChild(countryCard);
}

// Display countries
function displayCountries(countries) {
    spinnerEl.classList.add("d-none");
    resultCountriesEl.textContent = "";
    for (let country of countries) {
        createAndAppendCountry(country);
    }
}

// Filter countries on input
function filterCountries() {
    let searchValue = searchInputEl.value.toLowerCase();
    let filteredList = countriesList.filter(country =>
        country.name.toLowerCase().includes(searchValue)
    );
    displayCountries(filteredList);
}

spinnerEl.classList.remove("d-none");
fetch("https://apis.ccbp.in/countries-data")
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {
        countriesList = data;
        displayCountries(countriesList);
    });