let s = document.getElementById("counterValue");
let counterValue = parseInt(s.textContent);
let b = document.getElementById("incrementBtn");
b.onclick = function() {
    counterValue = counterValue + 1;
    localStorage.setItem("clickCount", counterValue);
    s.textContent = counterValue;
}