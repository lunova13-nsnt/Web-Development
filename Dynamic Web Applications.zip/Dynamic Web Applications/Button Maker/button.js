let bgColor = document.getElementById("bgColorInput");
let fontColor = document.getElementById("fontColorInput");
let fontSize = document.getElementById("fontSizeInput");
let fontWeight = document.getElementById("fontWeightInput");
let padding = document.getElementById("paddingInput");
let border = document.getElementById("borderRadiusInput");
let button = document.getElementById("customButton");

function applyButton() {
    let bg = bgColor.value;
    let fontC = fontColor.value;
    let fontS = fontSize.value;
    let fontW = fontWeight.value;
    let p = padding.value;
    let b = border.value;

    button.style.backgroundColor = bg;
    button.style.color = fontC;
    button.style.fontSize = fontS;
    button.style.fontWeight = fontW;
    button.style.padding = p;
    button.style.borderRadius = b;
}