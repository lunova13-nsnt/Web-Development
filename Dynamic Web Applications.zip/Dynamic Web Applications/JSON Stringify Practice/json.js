let bikes = ["Hero", "Honda", "Bajaj", "Suzuki", "Yamaha"];
let person = {
    name: "Rahul",
    age: 25,
    gender: "Male",
};
let todos = [{
        todo: "Attending CCBP sessions",
        todoStatus: "Completed",
    },
    {
        todo: "Completing practice sets",
        todoStatus: "Not Completed",
    },
    {
        todo: "Asking doubts",
        todoStatus: "Completed",
    },
];

let p = document.getElementById("para");
let string = JSON.stringify(bikes);
p.classList.add("p");
p.textContent = string;

let p1 = document.getElementById("para1");
let string1 = JSON.stringify(person);
p1.classList.add("p");
p1.textContent = string1;

let p2 = document.getElementById("para2");
let string2 = JSON.stringify(todos);
p2.classList.add("p");
p2.textContent = string2;