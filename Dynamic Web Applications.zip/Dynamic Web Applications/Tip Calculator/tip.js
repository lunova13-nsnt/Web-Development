let bill = document.getElementById("billAmount");
let percent = document.getElementById("percentageTip");
let tip = document.getElementById("tipAmount");
let total = document.getElementById("totalAmount");
let error = document.getElementById("errorMessage");

function calculateButton() {
    let billValue = bill.value;
    let percentValue = percent.value;

    if (billValue === "" || percentValue === "") {
        error.textContent = "Please Enter a Valid Input";
        error.style.color = "Red";
    } else {
        error.textContent = "";
        let b = parseInt(billValue);
        let p = parseInt(percentValue);

        let calculatedTip = (p / 100) * b;
        let calculatedTotal = b + calculatedTip;

        tip.value = calculatedTip;
        total.value = calculatedTotal;
    }
}