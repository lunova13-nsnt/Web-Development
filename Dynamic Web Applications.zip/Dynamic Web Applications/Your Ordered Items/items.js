let itemList = [{
        itemName: "Veg Biryani",
        uniqueNo: 1,
    },
    {
        itemName: "Chicken 65",
        uniqueNo: 2,
    },
    {
        itemName: "Paratha",
        uniqueNo: 3,
    }
];

let container = document.getElementById("orderedItemsContainer");
let head = document.createElement("h1");
head.textContent = "Your Ordered Items";
head.classList.add("p-3")
container.appendChild(head);

let uList = document.createElement("ul");
container.appendChild(uList);

function orders(order) {
    let itemId = "item" + order.uniqueNo;
    let buttonId = "button" + order.uniqueNo;

    let list = document.createElement("li");
    list.classList.add("d-flex", "flex-row", "p-3");
    list.id = itemId;
    uList.appendChild(list);

    let para = document.createElement("p");
    para.textContent = order.itemName;
    para.classList.add("pr-3");
    list.appendChild(para);

    let button = document.createElement("button");
    button.textContent = "Cancel";
    button.classList.add("btn", "btn-danger", "text-white");
    button.id = buttonId;
    list.appendChild(button);

    let b = document.createElement("br");
    list.appendChild(b);

    function del() {
        list.removeChild(para);
        list.removeChild(button)
    }

    button.onclick = function() {
        del();
    }
}

for (let i of itemList) {
    orders(i);
}