let arr = [1, 7, 3, 1, 0, 20, 77];
let array = document.getElementById("updatedArray");
let a = JSON.stringify(arr);
array.textContent = a;
array.classList.add("text");

let spliceBtn = document.getElementById("spliceBtn");
spliceBtn.onclick = function() {
    let startIndexInput = document.getElementById("startIndexInput");
    let deleteCountInput = document.getElementById("deleteCountInput");
    let itemToAddInput = document.getElementById("itemToAddInput");
    let startVal = startIndexInput.value;

    if (startVal === "") {
        alert("Please enter start Index");
        return;
    }

    // Convert inputs to numbers where needed
    let s = parseInt(startVal);
    let d = parseInt(deleteCountInput.value) || 0; // Default to 0 if empty
    let item = itemToAddInput.value; // Keep as string

    // Modify ORIGINAL array
    if (item === "") {
        arr.splice(s, d);
    } else {
        arr.splice(s, d, item);
    }

    // Update display from original array
    array.textContent = JSON.stringify(arr);

    // Clear inputs like solution code
    startIndexInput.value = "";
    deleteCountInput.value = "";
    itemToAddInput.value = "";
};