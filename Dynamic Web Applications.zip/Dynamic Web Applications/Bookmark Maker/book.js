let form = document.getElementById("bookmarkForm");
let nameEl = document.getElementById("siteNameInput");
let urlEl = document.getElementById("siteUrlInput");
let nameErr = document.getElementById("siteNameErrMsg");
let urlErr = document.getElementById("siteUrlErrMsg");
let btn = document.getElementById("submitBtn");

let formData = {
    url: "",
    name: ""
};

function rName(formData) {
    let rn = formData.name.trim();
    if (rn === "") {
        nameErr.textContent = "Required*";
        return false;
    } else {
        nameErr.textContent = "";
        return true;
    }
}

function rUrl(formData) {
    let ru = formData.url.trim();
    if (ru === "") {
        urlErr.textContent = "Required*";
        return false;
    } else {
        urlErr.textContent = "";
        return true;
    }
}

nameEl.addEventListener("change", function(event) {
    formData.name = event.target.value;
    rName(formData);
});

urlEl.addEventListener("change", function(event) {
    formData.url = event.target.value;
    rUrl(formData);
});

form.addEventListener("submit", function(event) {
    event.preventDefault();

    let isNameValid = rName(formData);
    let isUrlValid = rUrl(formData);

    if (isNameValid && isUrlValid) {
        let {
            url,
            name
        } = formData;
        let ul = document.getElementById("bookmarksList");

        let list = document.createElement("li");
        list.classList.add("list");

        let text = document.createElement("h1");
        text.classList.add("h2");
        text.textContent = name;
        list.appendChild(text);

        let anchor = document.createElement("a");
        anchor.setAttribute("href", url);
        anchor.setAttribute("target", "_blank");
        anchor.textContent = url;
        list.appendChild(anchor);

        ul.appendChild(list);
    }
});