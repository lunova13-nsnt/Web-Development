let container = document.getElementById("checkBoxWithLabelContainer");

let input = document.createElement("input");
input.type = "checkbox";
input.id = 'checkbox';
container.appendChild(input);

let label = document.createElement("label");
label.htmlFor = "checkbox";
label.id = "checkboxLabel";
label.textContent = "I am a label";
container.appendChild(label);

function onStatusChange() {
    label.classList.toggle("label");
}

input.onclick = function() {
    onStatusChange();
}