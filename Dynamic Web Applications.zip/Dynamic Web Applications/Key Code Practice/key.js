let input = document.getElementById("userInput");
let code = document.getElementById("keyCodeList");
input.addEventListener("keydown", function(event) {
    let key = event.keyCode;
    let list = document.createElement("li");
    list.textContent = key;
    code.appendChild(list);
})