let s = document.getElementById("stopLight")
let r = document.getElementById("readyLight");
let st = document.getElementById("goLight");
let stop = document.getElementById("stopButton");
let ready = document.getElementById("readyButton");
let start = document.getElementById("goButton");

function stopButton() {
    s.style.backgroundColor = "#cf1124";
    stop.style.backgroundColor = "#cf1124";
    r.style.backgroundColor = "#4b5069";
    ready.style.backgroundColor = "#1f1d41";
    st.style.backgroundColor = "#4b5069";
    start.style.backgroundColor = "#1f1d41";
}

function readyButton() {
    r.style.backgroundColor = "#f7c948";
    ready.style.backgroundColor = "#f7c948";
    s.style.backgroundColor = "#4b5069";
    stop.style.backgroundColor = "#1f1d41";
    st.style.backgroundColor = "#4b5069";
    start.style.backgroundColor = "#1f1d41";
}

function goButton() {
    st.style.backgroundColor = "#199473";
    start.style.backgroundColor = "#199473";
    s.style.backgroundColor = "#4b5069";
    stop.style.backgroundColor = "#1f1d41";
    r.style.backgroundColor = "#4b5069";
    ready.style.backgroundColor = "#1f1d41";
}