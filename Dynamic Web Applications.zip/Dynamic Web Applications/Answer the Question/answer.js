let form = document.getElementById("questionsForm");
let resultMsg = document.getElementById("resultMsg");

// Add change event listener to radio buttons
let radioButtons = document.querySelectorAll('input[name="capital"]');
radioButtons.forEach(function(radio) {
    radio.addEventListener("change", function() {
        if (this.value === "Delhi") {
            resultMsg.textContent = "Correct answer!";
            resultMsg.style.color = "green";
        } else {
            resultMsg.textContent = "Wrong answer!!";
            resultMsg.style.color = "red";
        }
    });
});

// Keep the submit event listener (if needed for form submission)
form.addEventListener("submit", function(event) {
    event.preventDefault();
    let selectedOption = document.querySelector('input[name="capital"]:checked');
    if (!selectedOption) {
        resultMsg.textContent = "Please select the answer.";
        resultMsg.style.color = "red";
    }
});