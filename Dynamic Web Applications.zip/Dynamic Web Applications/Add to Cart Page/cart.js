let mainContainer = document.getElementById("mainContainer");
let container = document.getElementById("container");
let head = document.createElement("h1");
head.textContent = "Add To Cart";
mainContainer.appendChild(head);

let input = document.createElement("input");
input.type = "text";
input.id = "cartItemTextInput";
mainContainer.appendChild(container);
container.appendChild(input);

let button = document.createElement("button");
button.textContent = "Add";
button.id = "addBtn";
button.classList.add("btn", "btn-primary");
container.appendChild(button);

let para = document.createElement("p");
para.textContent = "My Cart items";
para.classList.add("p");
mainContainer.appendChild(para);

button.onclick = function() {
    let a = input.value;
    let list = document.createElement("li");
    list.textContent = a;
    list.classList.add("list")
    mainContainer.appendChild(list);
}