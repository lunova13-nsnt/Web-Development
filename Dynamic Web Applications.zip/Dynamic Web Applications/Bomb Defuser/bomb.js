let timer = document.getElementById("timer");
let input = document.getElementById("defuser");

let value = "";
input.addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
        value = input.value;
    }
});

let counter = 10;
timer.textContent = counter;

let interval = setInterval(function() {
    counter = counter - 1;

    if (value === "defuse" && counter >= 1) {
        clearInterval(interval);
        timer.textContent = "You Did it!";
    } else if (counter === 0) {
        clearInterval(interval);
        timer.textContent = "BOOM";
    } else {
        timer.textContent = counter;
    }
}, 1000);