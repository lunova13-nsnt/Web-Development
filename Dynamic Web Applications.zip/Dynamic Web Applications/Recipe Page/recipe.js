let recipeObj = {
    title: "Tomato Pasta",
    imgSrc: "https://d2clawv67efefq.cloudfront.net/ccbp-dynamic-webapps/recipe-img.png",
    ingredients: ["Pasta", "Oil", "Onions", "Salt", "Tomato Pasta Sauce", "Cheese"]
};

let container = document.getElementById("container");

let recipeTitle = document.createElement("h1");
recipeTitle.textContent = recipeObj.title;
recipeTitle.classList.add("recipe-title");
container.appendChild(recipeTitle);

let image = document.createElement("img");
image.setAttribute("src", recipeObj.imgSrc);
image.classList.add("image");
container.appendChild(image);

let list = document.getElementById("ingredientsContainer");
container.appendChild(list);

let u = document.getElementById("uList");

for (let i in recipeObj.ingredients) {
    let l = document.createElement("li");
    l.textContent = recipeObj.ingredients[i];
    l.classList.add("ingredients-list")
    u.appendChild(l)

}