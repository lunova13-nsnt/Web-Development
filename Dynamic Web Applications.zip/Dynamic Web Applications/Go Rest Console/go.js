let consoleFormEl = document.getElementById("consoleForm");
let requestUrlEl = document.getElementById("requestUrl");
let requestUrlErrMsgEl = document.getElementById("requestUrlErrMsg");
let requestMethodEl = document.getElementById("requestMethod");
let requestBodyEl = document.getElementById("requestBody");
let responseStatusEl = document.getElementById("responseStatus");
let responseBodyEl = document.getElementById("responseBody");

let formData = {
    requestUrl: "https://gorest.co.in/public-api/users",
    requestMethod: "POST",
    requestBody: ""
};

requestMethodEl.addEventListener("change", function() {
    formData.requestMethod = requestMethodEl.value;
});

requestUrlEl.addEventListener("change", function() {
    formData.requestUrl = requestUrlEl.value;
});

requestBodyEl.addEventListener("change", function() {
    formData.requestBody = requestBodyEl.value;
});

function rUrl(formData) {
    let ru = formData.requestUrl;
    if (ru === "") {
        requestUrlErrMsgEl.textContent = "Required*";
        return false;
    } else {
        requestUrlErrMsgEl.textContent = "";
        return true;
    }
}

function sendRequest(formData) {
    let {
        requestUrl,
        requestMethod,
        requestBody
    } = formData;

    let options = {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: "Bearer YOUR_TOKEN_HERE"
        }
    };

    if (requestMethod === "POST" || requestMethod === "PUT") {
        options.body = requestBody;
    }

    fetch(requestUrl, options)
        .then(function(response) {
            return response.json()
        })
        .then(function(jsonData) {
            let responseStatus = jsonData.code;
            let responseBody = JSON.stringify(jsonData);
            responseStatusEl.value = responseStatus;
            responseBodyEl.value = responseBody;
        });
}

consoleFormEl.addEventListener("submit", function(event) {
    event.preventDefault();
    if (rUrl(formData)) {
        sendRequest(formData);
    }
});