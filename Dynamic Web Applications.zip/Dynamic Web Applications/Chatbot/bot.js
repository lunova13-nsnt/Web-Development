let chatbotMsgList = ["Hi", "Hey", "Good Morning", "Good Evening", "How can I help you?", "Thank You"];
let btn = document.getElementById("sendMsgBtn");
let input = document.getElementById("userInput");
let chat = document.getElementById("chatContainer");
let count = 0;
let l = chatbotMsgList.length;
btn.onclick = function() {
    let userText = input.value;

    let msgContainerEl = document.createElement("span");
    msgContainerEl.classList.add("msg-to-chatbot-container", "msg-to-chatbot");
    msgContainerEl.textContent = userText;
    chat.appendChild(msgContainerEl);
    input.value = "";

    let chatbotMsgEl = document.createElement("span");
    chatbotMsgEl.classList.add("msg-from-chatbot-container", "msg-from-chatbot");
    let chatbotMsg = chatbotMsgList[Math.ceil(Math.random() * l - 1)];
    chatbotMsgEl.textContent = chatbotMsg;
    chat.appendChild(chatbotMsgEl);
    count++;
};