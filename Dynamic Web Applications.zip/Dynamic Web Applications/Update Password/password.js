let form = document.getElementById("updatePasswordForm");
let newPass = document.getElementById("newPassword");
let confirmPass = document.getElementById("confirmPassword");
let msgNew = document.getElementById("newPasswordErrMsg");
let msgConfirm = document.getElementById("confirmPasswordErrMsg");
let btn = document.getElementById("updateBtn");

newPass.addEventListener("blur", function() {
    if (newPass.value === "") {
        msgNew.textContent = "Required*";
    } else {
        msgNew.textContent = "";
    }
});
confirmPass.addEventListener("blur", function() {
    if (confirmPass.value === "") {
        msgConfirm.textContent = "Required*";
    } else {
        msgConfirm.textContent = "";
    }
});
form.addEventListener("submit", function(event) {
    event.preventDefault();

    if (newPass.value === "") {
        msgNew.textContent = "Required*";
    } else {
        msgNew.textContent = "";
    }

    if (confirmPass.value === "") {
        msgConfirm.textContent = "Required*";
    } else {
        msgConfirm.textContent = "";
    }
});

btn.onclick = function() {
    if (newPass.value !== confirmPass.value) {
        msgConfirm.textContent = "Password must be same";
    } else {
        msgConfirm.textContent = "";
    }
}