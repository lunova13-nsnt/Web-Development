let subscribeForm = document.getElementById("subscribeForm");

let nameEl = document.getElementById("name");
let nameErrMsg = document.getElementById("nameErrMsg");

let emailEl = document.getElementById("email");
let emailErrMsg = document.getElementById("emailErrMsg");

nameEl.addEventListener("blur", function() {
    if (nameEl.value === "") {
        nameErrMsg.textContent = "Required*";
    } else {
        nameErrMsg.textContent = "";
    }
});

emailEl.addEventListener("blur", function() {
    if (emailEl.value === "") {
        emailErrMsg.textContent = "Required*";
    } else {
        emailErrMsg.textContent = "";
    }
});

subscribeForm.addEventListener("submit", function(event) {
    event.preventDefault();

    if (nameEl.value === "") {
        nameErrMsg.textContent = "Required*";
    } else {
        nameErrMsg.textContent = "";
    }

    if (emailEl.value === "") {
        emailErrMsg.textContent = "Required*";
    } else {
        emailErrMsg.textContent = "";
    }
});