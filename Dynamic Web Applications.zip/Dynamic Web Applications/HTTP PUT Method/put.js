let input = document.getElementById("userInput");
let id = input.value;
let r = document.getElementById("requestBody");
let data = r.value;
let putBtn = document.getElementById("sendPutRequestBtn");
putBtn.onclick = function() {
    let options = {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: "Bearer " + id
        },
        body: JSON.stringify(data)
    };
    let request = document.getElementById("requestStatus");
    let response = document.getElementById("httpResponse");
    fetch("https://gorest.co.in/public-api/users/" + id, options)
        .then(function(response) {
            return response.json()
        })
        .then(function(data) {
            response.textContent = JSON.stringify(data);
            let v1 = data.code;
            request.textContent = v1;
        });
}