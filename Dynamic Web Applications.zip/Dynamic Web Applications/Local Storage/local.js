let msg = document.getElementById("msg");
let save = document.getElementById("saveBtn");
let clear = document.getElementById("clearBtn");
let s = "userInput";
save.onclick = function() {
    let k = msg.value;
    localStorage.setItem(s, k);
}
clear.onclick = function() {
    localStorage.removeItem(s);
    msg.value = "";
}