let bgColor = document.getElementById("colorPickerContainer");
let color = document.getElementById("selectedColorHexCode");

function button1() {
    bgColor.style.backgroundColor = "#e0e0e0";
    color.textContent = "#e0e0e0";
}

function button2() {
    bgColor.style.backgroundColor = "#6fcf97";
    color.textContent = "#6fcf97";
}

function button3() {
    bgColor.style.backgroundColor = "#56ccf2";
    color.textContent = "#56ccf2";
}

function button4() {
    bgColor.style.backgroundColor = "#bb6bd9";
    color.textContent = "#bb6bd9";
}