let imageElement = document.getElementById("image");
let warning = document.getElementById("warningMessage");
let width = document.getElementById("imageWidth");
let max_width = 300;
let min_width = 100;
let original_width = 200;
let min_error = "Can't Visible, Increase the size of the Image. ";
let max_error = "Too big, Decrease the size of the Image.";

function increment() {
    if (original_width >= max_width) {
        warning.textContent = max_error;
    } else {
        warning.textContent = "";
        original_width = original_width + 5;
        let u = original_width + "px";
        imageElement.style.width = u;
        width.textContent = u;
    }
}

function decrement() {
    if (original_width <= min_width) {
        warning.textContent = min_error;
    } else {
        warning.textContent = "";
        original_width = original_width - 5;
        let u = original_width + "px";
        imageElement.style.width = u;
        width.textContent = u;
    }
}