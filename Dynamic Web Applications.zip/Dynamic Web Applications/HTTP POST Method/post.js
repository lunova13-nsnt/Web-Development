let r = document.getElementById("requestBody");
let data = r.value;
let postBtn = document.getElementById("sendPostRequestBtn");
postBtn.onclick = function() {
    let options = {
        method: "POST",
        header: {
            "Content-Type": "application/json",
            Accept: "application/json",
        },
        body: JSON.stringify(data)
    };
    let request = document.getElementById("requestStatus");
    let response = document.getElementById("httpResponse");
    fetch("https://gorest.co.in/public-api/users", options)
        .then(function(response) {
            return response.json()
        })
        .then(function(data) {
            response.textContent = JSON.stringify(data);
            let v1 = data.code;
            request.textContent = v1;
        });
}