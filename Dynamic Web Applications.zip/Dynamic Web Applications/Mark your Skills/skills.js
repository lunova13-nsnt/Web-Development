let skillList = [{
        skillName: "HTML",
        uniqueNo: 1,
    },
    {
        skillName: "CSS",
        uniqueNo: 2,
    },
    {
        skillName: "JavaScript",
        uniqueNo: 3,
    }
];

let container = document.getElementById("skillsContainer");
let head = document.createElement("h1");
head.textContent = "Mark your Skills";
container.appendChild(head);

let uList = document.createElement("ul");
container.appendChild(uList);

function createAndAppend(list) {
    let checkboxId = "checkbox" + list.uniqueNo;
    let labelId = "label" + list.uniqueNo;

    let l = document.createElement("li");
    l.classList.add("listIcon")
    uList.appendChild(l);

    let input = document.createElement("input");
    input.id = checkboxId;
    input.type = "checkbox";
    l.appendChild(input);

    let label = document.createElement("label");
    label.htmlFor = checkboxId;
    label.id = labelId;
    label.textContent = list.skillName;
    label.classList.add("list");
    l.appendChild(label);

    let b = document.createElement("br");
    l.appendChild(b);

    function onStatusChange() {
        label.classList.toggle("label");
    }
    input.onclick = function() {
        onStatusChange();
    }
}

for (let i of skillList) {
    createAndAppend(i);
}