let input = document.getElementById("userInput");
let id = input.value;
let deleteBtn = document.getElementById("sendDeleteRequestBtn");
deleteBtn.onclick = function() {
    let options = {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: "?"
        },
    };
    let request = document.getElementById("requestStatus");
    let response = document.getElementById("httpResponse");
    fetch("https://gorest.co.in/public-api/users/" + id, options)
        .then(function(response) {
            return response.json()
        })
        .then(function(data) {
            response.textContent = JSON.stringify(data);
            let v1 = data.code;
            request.textContent = v1;
        });
}