let about = document.getElementById("aboutTab");
let time = document.getElementById("timeToVisitTab");
let attract = document.getElementById("attractionsTab");
let a = document.getElementById("aboutButton");
let t = document.getElementById("timeToVisitButton");
let at = document.getElementById("attractionsButton");
time.classList.add("d-none");
attract.classList.add("d-none");
about.classList.add("d-none");

function aboutButton() {
    about.classList.remove("d-none");
    time.classList.add("d-none");
    attract.classList.add("d-none");

    a.classList.add("selected-button");
    t.classList.remove("selected-button");
    at.classList.remove("selected-button");
}

function timeToVisitButton() {
    about.classList.add("d-none");
    time.classList.remove("d-none");
    attract.classList.add("d-none");

    a.classList.remove("selected-button");
    t.classList.add("selected-button");
    at.classList.remove("selected-button");
}

function attractionsButton() {
    about.classList.add("d-none");
    time.classList.add("d-none");
    attract.classList.remove("d-none");

    a.classList.remove("selected-button");
    t.classList.remove("selected-button");
    at.classList.add("selected-button");
}